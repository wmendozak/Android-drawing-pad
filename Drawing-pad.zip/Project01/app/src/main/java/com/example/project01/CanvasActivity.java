package com.example.project01;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.github.gcacace.signaturepad.views.SignaturePad;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.karumi.dexter.listener.single.BasePermissionListener;
import com.karumi.dexter.listener.single.PermissionListener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import yuku.ambilwarna.AmbilWarnaDialog;

public class CanvasActivity extends AppCompatActivity {
    int defaultColor;
    SignaturePad signature_pad;
    ImageButton ibEraser, ibColor, ibSave;
    SeekBar sbPenSize;
    TextView tvPenSize;
    private static String filename;
    File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
    //File path = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/WMPainting");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_canvas);

        signature_pad = findViewById(R.id.signature_pad);
        sbPenSize = findViewById(R.id.ac_sbPenSize);
        tvPenSize = findViewById(R.id.ac_tvPenSize);
        ibColor = findViewById(R.id.ac_ibColor);
        ibEraser = findViewById(R.id.ac_ibEraser);
        ibSave = findViewById(R.id.ac_ibSave);

        requirePermission();
        setListeners();
    }

    private void setListeners() {
        defaultColor = ContextCompat.getColor(CanvasActivity.this, R.color.black);

        ibColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openColorPicker();
            }
        });

        sbPenSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tvPenSize.setText(i + "dp");
                signature_pad.setMinWidth(i);
                signature_pad.setMaxWidth(i);
                sbPenSize.setMin(5);
                sbPenSize.setMax(50);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        ibEraser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signature_pad.clear();
            }
        });

        ibSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!signature_pad.isEmpty()){
                    try {
                        saveImage();
                    } catch (IOException e) {
                        e.printStackTrace();
                        Toast.makeText( CanvasActivity.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void saveImage() throws IOException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault());
        String date = simpleDateFormat.format(new Date());

        filename = date + ".png";
        File file = new File(path, filename);

        Bitmap bitmap = signature_pad.getSignatureBitmap();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, bos);
        byte[] bitmapData = bos.toByteArray();

        FileOutputStream fos = new FileOutputStream(file);
        fos.write(bitmapData);
        fos.flush();
        fos.close();
        Toast.makeText( CanvasActivity.this, "Image saved", Toast.LENGTH_SHORT).show();
    }

    private void openColorPicker() {
        AmbilWarnaDialog ambilWarnaDialog = new AmbilWarnaDialog(this, defaultColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                defaultColor =  color;
                signature_pad.setPenColor(color);
            }
        });
        ambilWarnaDialog.show();
    }

    private void requirePermission() {
       Dexter.withContext(this)
                .withPermissions(Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport multiplePermissionsReport) {
                        //Toast.makeText( CanvasActivity.this, "Permission granted", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> list, PermissionToken permissionToken) {
                        permissionToken.continuePermissionRequest();
                    }
                }).check();
         /*if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT){
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PackageManager.PERMISSION_GRANTED);
            ActivityCompat.requestPermissions(this, new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE},
                    PackageManager.PERMISSION_GRANTED);
        }*/
    }

    void createFile(){
        String dataFileName = "file.text";
        String dataFileContent = "Aleluya!";
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
        /*try {
            if(!dir.exists()) {
                dir.mkdirs();
                }
            Toast.makeText(CanvasActivity.this, "Dir : " + dir.getAbsolutePath(), Toast.LENGTH_SHORT).show();
        }catch (Exception ex){
            ex.printStackTrace();
            Toast.makeText( CanvasActivity.this, "Error : " + ex.getMessage(), Toast.LENGTH_SHORT).show();
        }*/

        File contentFileName = new File(dir,dataFileName);
        try{
            FileOutputStream stream = new FileOutputStream(contentFileName);
            stream.write(dataFileContent.getBytes(StandardCharsets.UTF_8));
            stream.close();
            Toast.makeText( CanvasActivity.this, "File created", Toast.LENGTH_LONG).show();
        }catch (FileNotFoundException ex){
            ex.printStackTrace();

            tvPenSize.setText(ex.getMessage());
            tvPenSize.setSingleLine(false);
            Toast.makeText( CanvasActivity.this, "Error : " + ex.getMessage(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            e.printStackTrace();
            tvPenSize.setText(e.getMessage());
            tvPenSize.setSingleLine(false);
            Toast.makeText( CanvasActivity.this, "Error : " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}